#' mbGraphics.
#'
#' @name mbGraphics
#' @docType package
NULL
